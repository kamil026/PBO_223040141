package Latihan2;

public class Gelas {
	private String warna;
	public Gelas(String w)
	{
		warna = w;
	}
	// setter
	void setWarna(String w)
	{
		warna = w;
	}
	// getter
	String getWarna()
	{
		return warna;
	}
}
